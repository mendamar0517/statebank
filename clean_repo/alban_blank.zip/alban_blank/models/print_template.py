from odoo import models, fields, api


class PrintTemplate(models.Model):
    _name = 'print.template'
    _description = 'Албан бланкны загвар'
    _order = 'sequence, id'

    sequence = fields.Integer(string='Дд', default=1, readonly=True)

    @api.model
    def create(self, vals):
        last_record = self.search([], order='sequence desc', limit=1)
        if last_record:
            vals['sequence'] = last_record.sequence + 1
        else:
            vals['sequence'] = 1
        return super(PrintTemplate, self).create(vals)

    # Үндсэн талбарууд
    name = fields.Char(string='Загварын нэр', required=True)
    organization = fields.Char(string='Байгууллагын нэр')
    doc_type = fields.Selection([
        ('order', 'Тогтоол, Тушаал'),
        ('letter', 'Албан бичиг')
    ], string='Баримт бичгийн нэр')
    paper_size = fields.Selection([
        ('a4', 'A4'),
        ('a5', 'A5')
    ], string='Цаасны хэмжээ')
    approved_file = fields.Binary(string='Батлагдсан загвар')
    start_date = fields.Date(string='Ашиглаж эхэлсэн огноо')

    # Тэмдэглэл хадгалагдахгүй байх асуудлыг засахын тулд Text талбар хэвээр үлдээнэ
    note = fields.Text(string='Тэмдэглэл')

    state = fields.Selection([
        ('new', 'Шинэ'),
        ('active', 'Ашиглагдаж байгаа'),
        ('cancelled', 'Цуцлагдсан')
    ], default='new', string='Төлөв', tracking=True)

    # Товчлуурын функцүүд
    def action_confirm(self):
        self.write({'state': 'active'})

    def action_cancel(self):
        self.write({'state': 'cancelled'})

    # Ажилтан болон огноо
    def _get_default_employee(self):
        return self.env['hr.employee'].search([('user_id', '=', self.env.uid)], limit=1)

    employee_id = fields.Many2one(
        'hr.employee',
        string='Бүртгэсэн ажилтан',
        default=_get_default_employee,
        readonly=True,
        store=True
    )

    create_date = fields.Datetime(
        string='Бүртгэсэн огноо',
        default=fields.Datetime.now,
        readonly=True
    )