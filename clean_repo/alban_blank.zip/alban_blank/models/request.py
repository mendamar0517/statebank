from odoo import models, fields, api, _
from odoo.exceptions import ValidationError


class ArchiveRequest(models.Model):
    _name = 'archive.request'
    _description = 'Тодорхойлолт бичүүлэх хүсэлт'
    _inherit = ['mail.thread', 'mail.activity.mixin']  # Имэйл болон чат систем

    sequence = fields.Integer(string='Дд', default=1, readonly=True)

    # Төлөвүүд
    state = fields.Selection([
        ('new', 'Шинэ'),
        ('sent', 'Илгээсэн'),
        ('done', 'Олгосон')
    ], default='new', string='Төлөв', tracking=True)

    request_type = fields.Selection([
        ('certificate', 'Тодорхойлолт')
    ], string='Хүсэлтийн төрөл', default='certificate', readonly=True)

    # Хэрэглэгчийн бөглөх хэсэг (Зураг дээрх 'Гараас')
    z_code = fields.Char(string='Ажилтны Z code', required=True)
    organization = fields.Char(string='Хаана, ямар байгууллагад', required=True)
    about = fields.Text(string='Зориулалт', required=True)

    # Автомат талбарууд (Зураг дээрх 'Auto')
    request_employee_id = fields.Many2one('hr.employee', string='Хүсэлт илгээсэн ажилтан',
                                          default=lambda self: self.env.user.employee_id)
    request_date = fields.Date(string='Хүсэлт илгээсэн огноо', default=fields.Date.context_today)

    # ХН-ийн ажилтны бөглөх хэсэг
    email_to = fields.Char(string='Хүлээн авагчийн хаяг')
    approved_file = fields.Binary(string='Батлагдсан файл')
    sender_employee_id = fields.Many2one(
        'hr.employee',
        string='Илгээсэн ажилтан',
        default=lambda self: self.env.user.employee_id
    )

    # Илгээсэн огноо: Автоматаар одоогийн цагийг авна
    send_date = fields.Datetime(
        string='Илгээсэн огноо',
        default=fields.Datetime.now
    )

    def action_send_to_hr(self):
        """ХН-д илгээх товч"""
        template = self.env.ref('alban_blank.email_template_request_to_hr')  # Модулийн нэрийг шалгаарай
        for rec in self:
            rec.state = 'sent'
            template.send_mail(rec.id, force_send=True)

    def action_approve(self):
        """Олгосон товч"""
        template = self.env.ref('alban_blank.email_template_response_to_employee')
        for rec in self:
            if not rec.approved_file:
                raise ValidationError("Батлагдсан файлыг оруулна уу!")
            rec.sender_employee_id = self.env.user.employee_id
            rec.send_date = fields.Datetime.now()
            rec.state = 'done'
            template.send_mail(rec.id, force_send=True)
